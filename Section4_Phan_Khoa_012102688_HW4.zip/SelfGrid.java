import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
Represents the player's own grid
*/
public class SelfGrid extends BattleGrid {
    Component[][] shipComp = new Component[10][10];						// self ship units
    MatrixShip[][] coordinateArray = new MatrixShip[3][5];				// to save coordinate ship
    int count = 0;														// to store number of ship (cell), max = 15
    PlayerScreen player;
    
    public SelfGrid()
    {
        super();
        //create a array to save ship data
		for (int i = 0; i < 3; i++)
		{
	    	for (int j = 0; j < 5; j++)
	    	{
	    		coordinateArray[i][j] = new MatrixShip(-1, -1);
	    	}
		}
    }

    @Override
    protected JPanel getCell()
    {
        JPanel panel = new JPanel();
        panel.addMouseListener(new MouseHandler());
        panel.setLayout(null);
        panel.setBackground(Color.BLACK);
        panel.setBorder(BorderFactory.createMatteBorder(1,1,0,0, Color.GREEN));
        panel.setPreferredSize(new Dimension(20, 20)); // for demo purposes only

        return panel;
    }

    private class MouseHandler implements MouseListener{
    	public void mouseClicked(MouseEvent e)
    	{  		
    		// check total ships, max = 15 units
    		if (count < 16)
    		{
    			// to get mouse click
	    		int rowIndex = -1;
	            int colIndex = -1;
	            for (int i = 0; i < 10; i++)
	            {
	                for (int j = 0; j < 10; j++)
	                {
	                    if (comp[i][j] == e.getComponent())
	                    {
	                        rowIndex = i;
	                        colIndex = j;
	                    }
	                }
	            }
	            
	            // check available cell
	            if (shipComp[rowIndex][colIndex] == null)
	            {
		            // max ship already 5 ships, 15 units
		            if (count == 15)
		            {
		            	JOptionPane.showMessageDialog(null, "You have 5 ships already");
		            }
		            // check 3 cells for 1 ship or max 15 ship already
		            else if (colIndex > 7 || shipComp[rowIndex][colIndex + 1] != null || shipComp[rowIndex][colIndex + 2] != null)
		            {
		            	JOptionPane.showMessageDialog(null, "Not enough 3 cells for a ship");
		            }
		            else // creating a default ship, 3 unit from left to right
		            {
			            shipComp[rowIndex][colIndex] = comp[rowIndex][colIndex];
			            shipComp[rowIndex][colIndex + 1] = comp[rowIndex][colIndex + 1];
			            shipComp[rowIndex][colIndex + 2] = comp[rowIndex][colIndex + 2];
			            shipComp[rowIndex][colIndex].setBackground(Color.YELLOW);
			            shipComp[rowIndex][colIndex + 1].setBackground(Color.YELLOW);
			            shipComp[rowIndex][colIndex + 2].setBackground(Color.YELLOW);
			            inputCoordinateArray(coordinateArray, count/3, rowIndex, colIndex);
			            count += 3;			//add 3 units (1 ship) to count
			            player.ownShip.setText("Number of own ships alive: " + count/3);
		            }
	            }
	            else // cell is used
	            { 	
	            	// check if cell is in head of the ship with checking head
	            	if (checkShipInArray(coordinateArray, rowIndex, colIndex, 0) != -1)
	            	{
	            		// store index of ship in array data ship
	            		int temp = checkShipInArray(coordinateArray, rowIndex, colIndex, 0);
	            		// corner top left
	            		if (rowIndex < 2 && colIndex < 2)
	            		{
	            			if (!turnBottomToRight(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnRightToBottom(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// corner top right
	            		else if (rowIndex < 2 && colIndex > 7)
	            		{
	            			if (!turnBottomToLeft(coordinateArray, rowIndex, colIndex, temp))
	            				JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// corner bottom left
	            		else if (rowIndex > 7 && colIndex < 2)
	            		{
	            			if (!turnRightToTop(coordinateArray, rowIndex, colIndex, temp))
	            				JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the top grid
	            		else if (rowIndex < 2 && colIndex  <= 7)
	            		{
	            			if (!turnRightToBottom(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnBottomToLeft(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnRightToLeft(coordinateArray, rowIndex, colIndex, temp))
	            						if (!turnBottomToRight(coordinateArray, rowIndex, colIndex, temp))
	            							JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the right grid
	            		else if (rowIndex <= 7 && colIndex  > 7)
	            		{
	            			if (!turnBottomToLeft(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnBottomToTop(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the bottom grid
	            		else if (rowIndex > 7 && colIndex  <= 7)
	            		{
	            			if (!turnRightToLeft(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnRightToTop(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the left grid
	            		else if (rowIndex <= 7 && colIndex  < 2)
	            		{
	            			if(!turnRightToBottom(coordinateArray, rowIndex, colIndex, temp))
	            				if(!turnBottomToTop(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnRightToTop(coordinateArray, rowIndex, colIndex, temp))
	            						if (!turnBottomToRight(coordinateArray, rowIndex, colIndex, temp))
	            							JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// inside of the grid where ship can turn 4 ways
	            		else
	            		{
	            			if (!turnRightToBottom(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnBottomToLeft(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnRightToLeft(coordinateArray, rowIndex, colIndex, temp))
        								if (!turnBottomToTop(coordinateArray, rowIndex, colIndex, temp))
        									if (!turnRightToTop(coordinateArray, rowIndex, colIndex, temp))
        										if (!turnBottomToRight(coordinateArray, rowIndex, colIndex, temp))
        											JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            	}
	            	//// check if cell is in tail of the ship
	            	else if (checkShipInArray(coordinateArray, rowIndex, colIndex, 2) != -1)
	            	{       
	            		// store index of ship in array data ship with cheking tail
	            		int temp = checkShipInArray(coordinateArray, rowIndex, colIndex, 2);
	            		// corner top right
	            		if (rowIndex < 2 && colIndex > 7)
	            		{
	            			if (!turnLeftToBottom(coordinateArray, rowIndex, colIndex, temp))
	            				JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// corner bottom right
	            		else if (rowIndex > 7 && colIndex > 7)
	            		{
	            			if (!turnLeftToTop(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnTopToLeft(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// corner bottom left
	            		else if (rowIndex > 7 && colIndex < 2)
	            		{
	            			if (!turnTopToRight(coordinateArray, rowIndex, colIndex, temp))
	            				JOptionPane.showMessageDialog(null, "No space to turn");
	            		} 
	            		// space of the top grid
	            		else if (rowIndex < 2 && colIndex  <= 7)
	            		{
	            			if (!turnLeftToRight(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnLeftToBottom(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the right grid
	            		else if (rowIndex <= 7 && colIndex  > 7)
	            		{
	            			if (!turnLeftToTop(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnTopToBottom(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnTopToLeft(coordinateArray, rowIndex, colIndex, temp))
	            						if (!turnLeftToBottom(coordinateArray, rowIndex, colIndex, temp))
	            							JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the bottom grid
	            		else if (rowIndex > 7 && colIndex  <= 7)
	            		{
	            			if (!turnLeftToTop(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnTopToRight(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnTopToLeft(coordinateArray, rowIndex, colIndex, temp))
	            						if (!turnLeftToRight(coordinateArray, rowIndex, colIndex, temp))
	            							JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// space of the left grid
	            		else if (rowIndex <= 7 && colIndex  < 2)
	            		{
	            			if (!turnTopToRight(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnTopToBottom(coordinateArray, rowIndex, colIndex, temp))
	            					JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            		// inside of the grid where ship can turn 4 ways
	            		else
	            		{
	            			if (!turnLeftToTop(coordinateArray, rowIndex, colIndex, temp))
	            				if (!turnTopToRight(coordinateArray, rowIndex, colIndex, temp))
	            					if (!turnLeftToRight(coordinateArray, rowIndex, colIndex, temp))
        								if (!turnTopToBottom(coordinateArray, rowIndex, colIndex, temp))
        									if (!turnTopToLeft(coordinateArray, rowIndex, colIndex, temp))
        										if (!turnLeftToBottom(coordinateArray, rowIndex, colIndex, temp))
        											JOptionPane.showMessageDialog(null, "No space to turn");
	            		}
	            	}
	            	else // cell is a middle of the ship
	            	{
	            		turnMidShip(coordinateArray, rowIndex, colIndex, checkShipInArray(coordinateArray, rowIndex, colIndex, 1));
	            	}
	            }
    		}
    		else //count = 16+, change to attack stage, disable selfGrid
    		{
    			JOptionPane.showMessageDialog(null, "This is attack stage!");
    		}
        }

        public void mousePressed(MouseEvent e) {
            //do nothing
        }

        public void mouseReleased(MouseEvent e) {
            //means as a click
        }

        public void mouseEntered(MouseEvent e) {
            //do nothing
        }

        public void mouseExited(MouseEvent e) {
            //do nothing
        }
    }
    
    public void setPlayer(PlayerScreen a)
    {
    	this.player = a;
    }
    
    //lock selfGrid
    public void lockSelfGrid()
    {
    	count = 16;
    }
    
    // input new ship into array ship
    public void inputCoordinateArray(MatrixShip[][] arr, int index, int r, int c)
    {
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r, c + 1);
    		arr[2][index] = new MatrixShip(r, c + 2);
	}
    
    // check ship outside with ship information in array
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public int checkShipInArray(MatrixShip[][] arr, int r, int c, int coor)
    {
    	for (int i = 0; i < 5; i ++)
    	{
    		if (arr[coor][i].getR() == r && arr[coor][i].getC() == c)
    			return i;
    	}
    	return -1;
    }
    
    //swap 2 cells, first cell will be remove and second cell will be new cell
    public void swap(int r1, int c1, int r2, int c2)
    {
    	shipComp[r1][c1].setBackground(Color.BLACK);
		shipComp[r1][c1] = null;
		shipComp[r2][c2] = comp[r2][c2];
        shipComp[r2][c2].setBackground(Color.YELLOW);
    }
    
    //check ship in function is same with ship in array date - head horizontal
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public boolean checkSameShipHH(MatrixShip[][] arr, int r, int c, int index)
    {
    	if (r == arr[0][index].getR() && c == arr[0][index].getC()
    			&& r == arr[1][index].getR() && (c + 1) == arr[1][index].getC()
    			&& r == arr[2][index].getR() && (c + 2) == arr[2][index].getC())
    	{
    		return true;
    	}
    	return false;
    }
    
    //check ship in function is same with ship in array date - head vertical
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public boolean checkSameShipHV(MatrixShip[][] arr, int r, int c, int index)
    {
    	if (r == arr[0][index].getR() && c == arr[0][index].getC()
    			&& (r + 1) == arr[1][index].getR() && c == arr[1][index].getC()
    			&& (r + 2) == arr[2][index].getR() && c == arr[2][index].getC())
    	{
    		return true;
    	}
    	return false;
    }
    
    //check ship in function is same with ship in array date - tail horizontal
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public boolean checkSameShipTH(MatrixShip[][] arr, int r, int c, int index)
    {
    	if (r == arr[0][index].getR() && (c - 2) == arr[0][index].getC()
    			&& r == arr[1][index].getR() && (c - 1) == arr[1][index].getC()
    			&& r == arr[2][index].getR() && c == arr[2][index].getC())
    	{
    		return true;
    	}
    	return false;
    }
    
    //check ship in function is same with ship in array date - tail vertical
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public boolean checkSameShipTV(MatrixShip[][] arr, int r, int c, int index)
    {
    	if ((r - 2) == arr[0][index].getR() && c == arr[0][index].getC()
    			&& (r - 1) == arr[1][index].getR() && c == arr[1][index].getC()
    			&& r == arr[2][index].getR() && c == arr[2][index].getC())
    	{
    		return true;
    	}
    	return false;
    } 
    
    //function will turn ship when click in mid point of ship
    public void turnMidShip(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check condition to  turn mid point with ship on right, left side
        if (r > 0 && r < 9 && c > 0 && c < 9 
        		&& shipComp[r][c + 1] != null && shipComp[r][c - 1] != null 
        		&& shipComp[r - 1][c] == null && shipComp[r + 1][c] == null)
        {
        	swap(r, c - 1, r - 1, c);
        	swap(r, c + 1, r + 1, c);
        	arr[0][index] = new MatrixShip(r - 1, c);
        	arr[1][index] = new MatrixShip(r, c);
        	arr[2][index] = new MatrixShip(r + 1, c);
        }
        // check condition to  turn mid point with ship on top, bottom side
        else if (r > 0 && r < 9 && c > 0 && c < 9 
        		&& shipComp[r - 1][c] != null && shipComp[r + 1][c] != null 
        		&& shipComp[r][c + 1] == null && shipComp[r][c - 1] == null)           		
        {
        	swap(r - 1, c, r, c - 1);
        	swap(r + 1, c, r, c + 1);
        	arr[0][index] = new MatrixShip(r, c - 1);
        	arr[1][index] = new MatrixShip(r, c);
        	arr[2][index] = new MatrixShip(r, c + 1);
        }
        // no way to turn ship 
        else
        {
        	JOptionPane.showMessageDialog(null, "No space to turn");
        }
    }
    
    // function turns ship from right to bottom
    public boolean turnRightToBottom(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check right side of cell if right has ship and bottom is free
    	if (checkSameShipHH(arr, r, c, index) && shipComp[r + 1][c] == null && shipComp[r + 2][c] == null)
    	{
    		swap(r, c + 1, r + 1, c);
    		swap(r, c + 2, r + 2, c);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r + 1, c);
        	arr[2][index] = new MatrixShip(r + 2, c);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from bottom to right
    public boolean turnBottomToRight(MatrixShip[][] arr, int r, int c, int index)
    {
    	//// check bottom side of cell if bottom has ship and right is free
    	if (checkSameShipHV(arr, r, c, index) && shipComp[r][c + 1] == null && shipComp[r][c + 2] == null)
    	{
    		swap(r + 1, c, r, c + 1);
    		swap(r + 2, c, r, c + 2);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r, c + 1);
        	arr[2][index] = new MatrixShip(r, c + 2);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from bottom to left
    public boolean turnBottomToLeft(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check bottom side of cell if bottom has ship and left is free
    	if (checkSameShipHV(arr, r, c, index) && shipComp[r][c - 1] == null && shipComp[r][c - 2] == null)
    	{
    		swap(r + 1, c, r, c - 1);
    		swap(r + 2, c, r, c - 2);
    		arr[0][index] = new MatrixShip(r, c - 2);
    		arr[1][index] = new MatrixShip(r, c - 1);
    		arr[2][index] = new MatrixShip(r, c); 
    		return true;
    	}
    	return false;
    }
    
    // function turns ship from left to bottom
    public boolean turnLeftToBottom(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if left has ship and bottom is free
    	if (checkSameShipTH(arr, r, c, index) && shipComp[r + 1][c] == null && shipComp[r + 2][c] == null)
    	{
    		swap(r, c - 1, r + 1, c);
    		swap(r, c - 2, r + 2, c);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r + 1, c);
        	arr[2][index] = new MatrixShip(r + 2, c);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from left to top
    public boolean turnLeftToTop(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if left has ship and top is free
    	if (checkSameShipTH(arr, r, c, index) && shipComp[r - 1][c] == null && shipComp[r - 2][c] == null)
    	{
    		swap(r, c - 1, r - 1, c);
    		swap(r, c - 2, r - 2, c);
    		arr[0][index] = new MatrixShip(r - 2, c);
    		arr[1][index] = new MatrixShip(r - 1, c);       	
        	arr[2][index] = new MatrixShip(r, c);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from top  to left
    public boolean turnTopToLeft(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check top side of cell if top has ship and left is free
    	if (checkSameShipTV(arr, r, c, index) && shipComp[r][c - 1] == null && shipComp[r][c - 2] == null)
    	{
    		swap(r - 1, c, r, c - 1);
    		swap(r - 2, c, r, c - 2);  		
        	arr[0][index] = new MatrixShip(r, c - 2);
        	arr[1][index] = new MatrixShip(r, c - 1);
        	arr[2][index] = new MatrixShip(r, c);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from top to right
    public boolean turnTopToRight(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check top side of cell if top has ship and right is free
    	if (checkSameShipTV(arr, r, c, index) && shipComp[r][c + 1] == null && shipComp[r][c + 2] == null)
    	{
    		swap(r - 1, c, r, c + 1);
    		swap(r - 2, c, r, c + 2);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r, c + 1);
        	arr[2][index] = new MatrixShip(r, c + 2);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from right to top
    public boolean turnRightToTop(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check right side of cell if right has ship and top is free
    	if (checkSameShipHH(arr, r, c, index) && shipComp[r - 1][c] == null && shipComp[r - 2][c] == null)
    	{
    		swap(r, c + 1, r - 1, c);
    		swap(r, c + 2, r - 2, c);
    		arr[0][index] = new MatrixShip(r - 2, c);
    		arr[1][index] = new MatrixShip(r - 1, c);     	
        	arr[2][index] = new MatrixShip(r, c);
        	return true;
    	}
    	return false;
    }

    // function turns ship from left to right
    public boolean turnLeftToRight(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if left has ship and right is free
    	if (checkSameShipTH(arr, r, c, index) && shipComp[r][c + 1] == null && shipComp[r][c + 2] == null)
    	{
    		swap(r, c - 1, r, c + 1);
    		swap(r, c - 2, r, c + 2);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r, c + 1);     	
        	arr[2][index] = new MatrixShip(r, c + 2);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from right to left
    public boolean turnRightToLeft(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if right has ship and left is free
    	if (checkSameShipHH(arr, r, c, index) && shipComp[r][c - 1] == null && shipComp[r][c - 2] == null)
    	{
    		swap(r, c + 1, r, c - 1);
    		swap(r, c + 2, r, c - 2);
    		arr[0][index] = new MatrixShip(r, c - 2);
    		arr[1][index] = new MatrixShip(r, c - 1);     	
        	arr[2][index] = new MatrixShip(r, c);
        	return true;
    	}
    	return false;
    }
    
    // function turns ship from top to bottom
    public boolean turnTopToBottom(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if top has ship and bottom is free
    	if (checkSameShipTV(arr, r, c, index) && shipComp[r + 1][c] == null && shipComp[r + 2][c] == null)
    	{
    		swap(r - 1, c, r + 1, c);
    		swap(r - 2, c, r + 2, c);
    		arr[0][index] = new MatrixShip(r, c);
    		arr[1][index] = new MatrixShip(r + 1, c);     	
        	arr[2][index] = new MatrixShip(r + 2, c);
        	return true;
    	}
    	return false;
    }
     
    // function turns ship from bottom to top
    public boolean turnBottomToTop(MatrixShip[][] arr, int r, int c, int index)
    {
    	// check left side of cell if bottom has ship and top is free
    	if (checkSameShipHV(arr, r, c, index) && shipComp[r - 1][c] == null && shipComp[r - 2][c] == null)
    	{
    		swap(r + 1, c, r - 1, c);
    		swap(r + 2, c, r - 2, c);
    		arr[0][index] = new MatrixShip(r - 2, c);
    		arr[1][index] = new MatrixShip(r - 1, c);     	
        	arr[2][index] = new MatrixShip(r, c);
        	return true;
    	}
    	return false;
    }
}
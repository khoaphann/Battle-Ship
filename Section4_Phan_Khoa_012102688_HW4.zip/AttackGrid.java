import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
Represents the player's attack grid
*/
public class AttackGrid extends BattleGrid {
    Component[][] attackComp = new Component[10][10];     				// opponent's ship unit
    MatrixShip[][] shipArray = new MatrixShip[3][5];					// to save coordinate ship
    int countShip = 0;													// to store number of attack
    int msg = 0;														// choose msg to print out when hitting ship
    boolean gameEnd = false;											// a flag to close game at the end
    boolean attack = false;												// a flag to know if player press attack button or no
    int move = 0;														// count how many click on attack grid									
    PlayerScreen player;
   
    public AttackGrid()
    {
        super();
        //create a array to save ship data
      	for (int i = 0; i < 3; i++)
      	{
      	    for (int j = 0; j < 5; j++)
      	    {
      	    	shipArray[i][j] = new MatrixShip();
      	    }
      	}
    }

    @Override
    protected JPanel getCell()
    {
        JPanel panel = new JPanel();
        panel.addMouseListener(new MouseHandler());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createMatteBorder(1,1,0,0,Color.RED));
        panel.setPreferredSize(new Dimension(20, 20)); // for demo purposes only

        return panel;
    }

    private class MouseHandler implements MouseListener{
        public void mouseClicked(MouseEvent e)
        {
        	//a flag to know if player press attack button or no
        	if (attack)
        	{
	        	// check if cell is attacked or not
	        	if(e.getComponent().getBackground() != Color.GREEN && e.getComponent().getBackground() != Color.RED)
	        	{
		        	// to get mouse click
		    		int rowIndex = -1;
		            int colIndex = -1;
		            for (int i = 0; i < 10; i++)
		            {
		                for (int j = 0; j < 10; j++)
		                {
		                    if (comp[i][j] == e.getComponent())
		                    {
		                        rowIndex = i;
		                        colIndex = j;
		                        move++;						//increase move attack
		    		            attack = false; 			//change flag attack back to No
		                    }
		                }
		            }
		            
		            //check if cell has ship or no
		            // no ship in cell
		            if(attackComp[rowIndex][colIndex] == null)
		            {
		            	e.getComponent().setBackground(Color.RED);
		            	JOptionPane.showMessageDialog(null, "The attack is missed");
		            }
		            else // found out enemy ship
		            {
		            	//remove ship unit in array ship data
		            	if (checkShipInArray(shipArray, rowIndex, colIndex, 0) != -1)
		            	{
		            		int temp = checkShipInArray(shipArray, rowIndex, colIndex, 0);
		            		shipArray[0][checkShipInArray(shipArray, rowIndex, colIndex, 0)] = new MatrixShip( -1, -1);
		            		if (isShipSunk(shipArray, temp))
			            	{
		            			msg++;
			            	}
		            	}
		            	else if (checkShipInArray(shipArray, rowIndex, colIndex, 1) != -1)
		            	{
		            		int temp = checkShipInArray(shipArray, rowIndex, colIndex, 1);
		            		shipArray[1][checkShipInArray(shipArray, rowIndex, colIndex, 1)] = new MatrixShip( -1, -1);
		            		if (isShipSunk(shipArray, temp))
			            	{
		            			msg++;
			            	}
		            	}
		            	else
		            	{
		            		int temp = checkShipInArray(shipArray, rowIndex, colIndex, 2);
		            		shipArray[2][checkShipInArray(shipArray, rowIndex, colIndex, 2)] = new MatrixShip( -1, -1);
		            		if (isShipSunk(shipArray, temp))
			            	{
		            			msg++;
			            	}
		            	}
		            	//show a cell get hit
		            	e.getComponent().setBackground(Color.GREEN);
		            	// check msg to print out hit part of ship or ship is sunk
		            	if (msg != 0)
		            	{
		            		countShip++;
		            		JOptionPane.showMessageDialog(null, "Enemy ship is sunk");
		            		player.enemySunk.setText("Number of enemy ships sunk: " + countShip);
		            		if (countShip == 5)
		            		{
		            			JOptionPane.showMessageDialog(null, "All enemy ships are sunk.\nYou win");
		            			gameEnd = true;
		            		}
		            	}
		            	else
		            	{
		            		JOptionPane.showMessageDialog(null, "You hit a part of enemy ship");
		            	}
		            	msg = 0;
		            }
	        	}
	        	else // cell is already attacked
		        {
	        		JOptionPane.showMessageDialog(null, "You already attacked this cell");
	        	}
        	}
        	else //player does not press attack button or already attack
        	{
        		JOptionPane.showMessageDialog(null, "Please press \"Attack\" or \"Next\"");
        	}
        }

        public void mousePressed(MouseEvent e) {
            //do nothing
        }

        public void mouseReleased(MouseEvent e) {
            //means as a click
        }

        public void mouseEntered(MouseEvent e) {
            //do nothing
        }

        public void mouseExited(MouseEvent e) {
            //do nothing
        }
    }
    
    // check ship outside with ship information in array
    // coordinate can be 0 (head ship), 1 (mid ship), 2 (tail ship)
    public int checkShipInArray(MatrixShip[][] arr, int r, int c, int coor)
    {
    	for (int i = 0; i < 5; i ++)
    	{
    		if (arr[coor][i].getR() == r && arr[coor][i].getC() == c)
    			return i;
    	}
    	return -1;
    }
    
    //check if ship is sunk
    public boolean isShipSunk(MatrixShip[][] arr, int index)
    {
    	for (int i = 0; i < 3; i++)
    	{
    		if (arr[i][index].getR() != -1 || arr[i][index].getC() != -1)
    			return false;
    	}
    	return true;
    }
    
    public void setPlayer(PlayerScreen a)
    {
    	this.player = a;
    }
    
    //return count ship
    public int countReturn()
    {
    	return countShip;
    }
}
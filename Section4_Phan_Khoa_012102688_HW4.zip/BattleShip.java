import javax.swing.*;

public class BattleShip extends JFrame{
	static PlayerScreen player1, player2;
	
    public static void main(String[] args)
    {
        player1 = new PlayerScreen("Battle Ship", 1);
        player2 = new PlayerScreen("Battle Ship", 2);
        player2.setVisible(false);
    }
}
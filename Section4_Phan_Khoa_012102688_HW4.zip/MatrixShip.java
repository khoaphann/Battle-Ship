
public class MatrixShip {
	private int row, column;
	
	public MatrixShip() 
	{
		super();
	}
	
	public MatrixShip (int r, int c)
	{
		row = r;
		column = c;
	}
	
	public void setR(int r)
	{
		row = r;
	}
	
	public void setC(int c)
	{
		column = c;
	}

	public int getR()
	{
		return row;
	}
	
	public int getC()
	{
		return column;
	}
}

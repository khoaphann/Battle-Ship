import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;

public abstract class BattleGrid extends JPanel
{
    JPanel self = new JPanel();
    Component[][] comp = new Component[10][10];
    
    public BattleGrid()
    {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        
        JPanel screen = new JPanel();
        screen.setBackground(Color.BLUE);
        screen.setLayout(new GridBagLayout());
        
        GridBagConstraints grid = new GridBagConstraints();
        grid.fill = GridBagConstraints.BOTH;
        
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                self = getCell();
                if(i == 9)
                    self.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 0, ((MatteBorder)getCell().getBorder()).getMatteColor()));
                if(j == 9)
                    self.setBorder(BorderFactory.createMatteBorder(1, 1, 0, 1, ((MatteBorder)getCell().getBorder()).getMatteColor()));
                if(i == 9 && j == 9)
                    self.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, ((MatteBorder)getCell().getBorder()).getMatteColor()));
                
                comp[i][j] = self;       
                grid.gridy = i;
                grid.gridx = j;
                screen.add(self, grid);
            }
        }      
        add(screen);
    }
    
    protected abstract JPanel getCell();
}
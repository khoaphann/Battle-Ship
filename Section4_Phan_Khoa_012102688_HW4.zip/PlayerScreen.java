import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PlayerScreen extends BattleShip
{
	String gameName; 															//store game name
    int playerNumber; 															//player number 1 or 2
    String noticeDefault = "Enter player name here";  							//Messenger will use in JTextField
    JTextField nameText;  														//to enter player name
    JButton okButton, buildButton, attackButton, nextButton, resetButton; 		// button use in game
    JLabel ownShip, ownShipSunk, enemySunk, currentStatus, welcomeLabel; 					
    // display for status bar at the bottom		// currentStatus displays name player and turn on the top 	// welcomeLabel displays at begin of game
    SelfGrid selfGrid;
    AttackGrid attackGrid;
    MatrixShip[][] ship = new MatrixShip[3][5];
    int countMove = 0;						//compare with move in attack grip to lock button
    JPanel boxName, boxButton, boxStatus;
   
    public PlayerScreen(String name, int number)
    {
        this.gameName = name;
        this.playerNumber = number;
        this.setLayout(new BorderLayout());
        
        // a panel on the top of the game to tell player turn
        boxName = new JPanel();
        boxName.setLayout(new FlowLayout());
        boxName.setPreferredSize(new Dimension(700, 35));
        add(boxName, BorderLayout.NORTH);
        
        nameText = new JTextField(noticeDefault);
        nameText.setColumns(25);
        boxName.add(nameText);
        
        okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                    okFunction();
            }
        });
        boxName.add(okButton);
        
        // make a panel to store all button of the game
        boxButton = new JPanel();
        boxButton.setLayout(new GridBagLayout());
        boxButton.setPreferredSize(new Dimension(100, 300));
        boxButton.setBackground(Color.WHITE);
        add(boxButton, BorderLayout.CENTER);

        GridBagConstraints gridControl = new GridBagConstraints();
        gridControl.fill = GridBagConstraints.BOTH;
        gridControl.gridx = 0;
        
        gridControl.gridy = 0;
        welcomeLabel = new JLabel("Welcome to Battle Ship");
        welcomeLabel.setFont(new Font("Time New Roman", Font.BOLD, 30));     
        boxButton.add(welcomeLabel, gridControl);
        
        gridControl.gridy = 1;
        buildButton = new JButton("Build Ship"); 
        buildButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildShipFunction();
            }
        });    
        buildButton.setVisible(false);
        boxButton.add(buildButton, gridControl);
        
        gridControl.gridy = 2;
        resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetFunction();
            }
        }); 
        resetButton.setVisible(false);
        boxButton.add(resetButton, gridControl);
        
        gridControl.gridy = 3;
        nextButton = new JButton("Next");
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nextFunction();
            }
        });
        nextButton.setVisible(false);
        boxButton.add(nextButton, gridControl);
        
        gridControl.gridy = 4;
        attackButton = new JButton("Attack");
        attackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attackFunction();
            }
        }); 
        attackButton.setVisible(false);
        boxButton.add(attackButton, gridControl);
        
        // create a box status at bottom of game
        boxStatus = new JPanel();
        boxStatus.setLayout(new GridBagLayout());
        boxStatus.setPreferredSize(new Dimension(700, 100));
        add(boxStatus, BorderLayout.SOUTH);
        
        GridBagConstraints gridStatus = new GridBagConstraints();
        gridStatus.fill = GridBagConstraints.BOTH;
        gridStatus.gridx = 0;
        
        gridStatus.gridy = 0;
        currentStatus = new JLabel();
        boxStatus.add(currentStatus, gridStatus);
        
        gridStatus.gridy = 1;
        ownShip = new JLabel();
        boxStatus.add(ownShip, gridStatus);
        
        gridStatus.gridy = 2;
        ownShipSunk = new JLabel();
        boxStatus.add(ownShipSunk, gridStatus);
        
        gridStatus.gridy = 3;
        enemySunk = new JLabel();
        boxStatus.add(enemySunk, gridStatus);
        boxStatus.setVisible(false);
         
        //create self grid for player
        selfGrid = new SelfGrid();
        selfGrid.setPreferredSize(new Dimension(300, 300));
        selfGrid.setVisible(false);
        add(selfGrid, BorderLayout.WEST);
        
        //create attack grid for player
        attackGrid = new AttackGrid();
        attackGrid.setPreferredSize(new Dimension(300, 300));
        attackGrid.setVisible(false);
        add(attackGrid, BorderLayout.EAST);
           
        this.pack();
        this.setSize(700,400);
        this.setVisible(true);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle(gameName);
    }

    public void okFunction()
    {
        if(nameText.getText().equals(noticeDefault)) 
        {
            JOptionPane.showMessageDialog(null, "Please enter your name first!");
        }
        else
        {
        	boxName.setVisible(false);
            welcomeLabel.setVisible(false);
            buildButton.setVisible(true);  
            resetButton.setVisible(true);
            resetButton.setEnabled(false); 
            nextButton.setVisible(true); 
            boxStatus.setVisible(true);
            currentStatus.setText("Set up stage for " + nameText.getText());
            ownShip.setText("Number of own ships alive: 0");
            ownShipSunk.setText("Number of own ships sunk: 0");
            enemySunk.setText("Number of enemy ships sunk: 0");
            if (playerNumber == 1) 
            {
            	attackGrid.setPlayer(player1);
            	selfGrid.setPlayer(player1);
            }
            else
            {
            	attackGrid.setPlayer(player2);
            	selfGrid.setPlayer(player2);
            }
        }
    }

    public void buildShipFunction()
    {
        JOptionPane.showMessageDialog(null, "Please build 5 ships");
        buildButton.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        selfGrid.setVisible(true);
        buildButton.setEnabled(false);  
        resetButton.setEnabled(true); 
    }

    public void attackFunction()
    {
    	if (countMove == attackGrid.move)
    	{
    		attackGrid.attack = true;
    	}
    	attackButton.setEnabled(false);
    }

    public void nextFunction()
    {
    	if (attackGrid.gameEnd)
    	{
    		this.dispose();
    	}
    	if(selfGrid.count < 15)    // 5 ships take 15 units
    	{
    		JOptionPane.showMessageDialog(null, "You have to build 5 ships to continue");   
    	}
	    else
	    {
	    	if (playerNumber == 1)
	    		statusPlayer1();
	    	else
	    		statusPlayer2();
	    	if (selfGrid.count != 0)
	    	{
	    		buildButton.setVisible(false);
	    		resetButton.setVisible(false);
	    		attackButton.setVisible(true);
	    		attackButton.setEnabled(true);
	    		attackGrid.setVisible(true);
	    		if (player2.selfGrid.count != 0 && player2.selfGrid.count != 16)
		    	{
	    			deepCopy(player1, player2);
		    	}
	    	}
	    	if (selfGrid.count == 16 && attackGrid.move == countMove)
	    	{
	    		JOptionPane.showMessageDialog(null, "You have to attack before change turn");
	    	}
	    	else
	    	{
	        	countMove = attackGrid.move;
	    		switchPlayer();
	    		currentStatus.setText("Attack stage for " + nameText.getText() + " round " + (countMove + 1));
	    	}
	    	selfGrid.lockSelfGrid();
	    }
    }
    
    //reset self grid when building ship
    public void resetFunction()
    {
    	if(selfGrid.count > 0)
    	{
    		for (int row = 0; row < selfGrid.shipComp.length; row++)
    		{
    			for (int col = 0; col < selfGrid.shipComp.length; col++)
    			{
                    if (selfGrid.shipComp[row][col] != null)
                    {
                        selfGrid.shipComp[row][col].setBackground(Color.BLACK);
                        selfGrid.shipComp[row][col] = null;
                    }
                }
            }
    		for (int i = 0; i < 3; i++)
    		{
    	    	for (int j = 0; j < 5; j++)
    	    	{
    	    		selfGrid.coordinateArray[i][j] = new MatrixShip(-1, -1);
    	    	}
    		}
            selfGrid.count =0;
        }
    }	
    
    //change screen between two player
    public void switchPlayer()
    {
    	if (player1.isVisible())
    	{
    		player1.setVisible(false);
    		player2.setVisible(true);
    	}
    	else
    	{
    		player2.setVisible(false);
    		player1.setVisible(true);
    	}
    }
    
    // copy self grid from player a to attack grid of player b and opposite
    // copy ship array from player a to ship array of player b and opposite
    public void deepCopy(PlayerScreen a, PlayerScreen b)
    {
    	for (int i = 0; i < 10; i++)
    	{
    		for (int j = 0; j < 10; j++)
    		{
    			a.attackGrid.attackComp[i][j] = b.selfGrid.shipComp[i][j];
    			b.attackGrid.attackComp[i][j] = a.selfGrid.shipComp[i][j];
    		}
    	}
    	for (int i = 0; i < 3; i++)
    	{
    		for (int j = 0; j < 5; j++)
    		{
    			a.attackGrid.shipArray[i][j] = b.selfGrid.coordinateArray[i][j];
    			b.attackGrid.shipArray[i][j] = a.selfGrid.coordinateArray[i][j];
    		}
    	}
    }
    
    //print out data for player 1
    public void statusPlayer1()
    {
	    ownShip.setText("Number of own ships alive: " + (5 - player2.attackGrid.countReturn()));
	    ownShipSunk.setText("Number of own ships sunk: " + player2.attackGrid.countReturn());
    }
    
    //print out data for player 2
    public void statusPlayer2()
    {
    	ownShip.setText("Number of own ships alive: " + (5 - player1.attackGrid.countReturn()));
    	ownShipSunk.setText("Number of own ships sunk: " + player1.attackGrid.countReturn());
    }
}